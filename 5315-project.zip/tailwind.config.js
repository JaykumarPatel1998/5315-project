/** @type {import('tailwindcss').Config} */
export default {
  content: ["./views/**/*.{hbs,html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
